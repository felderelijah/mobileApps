//
//  My_Favorite_GamesTests.swift
//  My Favorite GamesTests
//
//  Created by Elijah Felder on 12/6/24.
//

import Testing
@testable import My_Favorite_Games

struct My_Favorite_GamesTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
