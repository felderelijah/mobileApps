//
//  Hello_WorldTests.swift
//  Hello WorldTests
//
//  Created by Elijah Felder on 12/7/24.
//

import Testing
@testable import Hello_World

struct Hello_WorldTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
