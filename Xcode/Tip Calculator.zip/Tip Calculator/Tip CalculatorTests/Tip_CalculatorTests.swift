//
//  Tip_CalculatorTests.swift
//  Tip CalculatorTests
//
//  Created by Elijah Felder on 12/7/24.
//

import Testing
@testable import Tip_Calculator

struct Tip_CalculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
