//
//  My_Favorite_PlaceTests.swift
//  My Favorite PlaceTests
//
//  Created by Elijah Felder on 11/13/24.
//

import Testing
@testable import My_Favorite_Place

struct My_Favorite_PlaceTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
